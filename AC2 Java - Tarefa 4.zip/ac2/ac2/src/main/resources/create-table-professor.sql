CREATE TABLE professor(
    id SERIAL PRIMARY KEY,
    nome TEXT,
    cpf INTEGER,
    rg INTEGER,
    endereco TEXT,
    celular INTEGER
)